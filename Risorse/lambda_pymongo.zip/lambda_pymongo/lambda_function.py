import pymongo
import os
import json

def lambda_handler(event, context):
    uri = os.environ.get('MONGO_URI', 'mongodb://example.com')
    client = pymongo.MongoClient(uri)
    db = client.test
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'pymongo importato correttamente'})
    }
